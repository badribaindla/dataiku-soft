#' Copies the whole content of a DSS folder to a local path
#'
#' @param folder_id the id of the DSS folder
#' @param local_base_path the local path (directory) to download to. If this path does not exist, it is created. 
#'
#' Files that are both in the source and destination are overwritten.
#' Files that exist in the destination but not in the DSS folder are preserved
#'
#' @export
dkuDownloadProjectLibraries <- function(project_key, local_base_path, subpath=NULL) {
    if (!dir.exists(local_base_path)) {
        dir.create(local_base_path, recursive=TRUE)
    }

    folder_paths <- dkuManagedFolderPartitionPaths(folder_id)

    for (folder_path in folder_paths) {
        local_path = paste0(local_base_path, folder_path)
        local_file = file(local_path, "wb")
        print(paste("Copying", folder_path, "to", local_path))
        data = dkuManagedFolderDownloadPath(folder_id, folder_path, as="raw")
        writeBin(data, local_file)
        close(local_file)
    }
    print("Done copying")
}