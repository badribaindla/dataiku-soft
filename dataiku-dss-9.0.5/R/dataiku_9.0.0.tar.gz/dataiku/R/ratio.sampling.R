ratio.sampling <- function(ratio) {
    if(!is.numeric(ratio) || ratio<0 || ratio>1) {
        stop(paste0("Invalid ratio (expected 0<=ratio<=1): ",ratio))
    }
    sampling <- {}
    sampling$samplingMethod <- "RANDOM_FIXED_RATIO"
    sampling$targetRatio <- ratio
    return(sampling)
}