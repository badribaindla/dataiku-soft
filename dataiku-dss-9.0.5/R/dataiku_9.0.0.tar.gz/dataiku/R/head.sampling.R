head.sampling <- function(nbrows) {
    if(!is.numeric(nbrows) || nbrows%%1 != 0 || nbrows<0) {
        stop(paste0("Invalid number of rows: ",nbrows))
    }
    sampling <- {}
    sampling$samplingMethod <- "HEAD_SEQUENTIAL"
    sampling$maxRecords <- nbrows
    return(sampling)
}